/**
 * 
 */
package test;

import static org.junit.Assert.*;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author hmicha01
 *
 */
public class LegalStaffTest {

	ClientConfig config = new ClientConfig();
	Client client = ClientBuilder.newClient(config);
	WebTarget target = client.target(UriBuilder.fromUri("http://localhost:80/LawOSREST").build());

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void editAppTest() {
		// Edit appointment
		Form form = new Form();
		form.param("AppointmentID", "42");
		form.param("Recommendation", "Kill yourself");
		form.param("LegalOpinion", "With a gun");
		String res19 = target.path("rest").path("lawos").path("ls").path("edit").path("app").request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class);

		System.out.println("LS : Edit appointment succeded? -> " + res19);
	}

	@Test
	public void viewAppTest() {
		// View appointment
		Form form = new Form();
		form.param("AppointmentID", "42");
		String res20 = target.path("rest").path("lawos").path("ls").path("view").path("app").request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class);

		System.out.println("LS : View appointment -> " + res20);
	}

	@Test
	public void editCaseTest() {
		// Edit an existing case
		Form form = new Form();
		form.param("CaseID", "4");
		form.param("Strategy", "Strategy2");
		form.param("Details", "None details at the moment.");
		form.param("Flagged_ml", "1");
		String res21 = target.path("rest").path("lawos").path("ls").path("edit").path("case").request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class);

		System.out.println("LS : Edit an existing case succeded? -> " + res21);
	}

	@Test
	public void viewAllCasesTest() {
		// View all cases of a client
		Form form = new Form();
		form.param("ClientID", "1");
		String res22 = target.path("rest").path("lawos").path("ls").path("view").path("allcases").request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class);

		System.out.println("LS : View all cases of a client -> " + res22);
	}

	@Test
	public void addCaseTest() {
		// Add new case
		Form form = new Form();
		form.param("Strategy", "Strategy4");
		form.param("Details", "This is a critical case.");
		form.param("Flagged_ml", "0");
		form.param("ClientID", "2");
		form.param("LawyerID", "1");
		String res23 = target.path("rest").path("lawos").path("ls").path("add").path("case").request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class);

		System.out.println("LS : Adding new case succeded? -> " + res23);
	}

	@Test
	public void viewSideEffectsTest() {
		// View side effects of a strategy
		Form form = new Form();
		form.param("Strategy", "Strategy4");
		String res24 = target.path("rest").path("lawos").path("ls").path("view").path("strategy").path("sideeffects")
				.request().accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class);

		System.out.println("LS : View side effects of a strategy -> " + res24);
	}

	@Test
	public void ismlTest() {
		// If a client is money laundry
		Form form = new Form();
		form.param("ClientID", "1");
		String res25 = target.path("rest").path("lawos").path("ls").path("view").path("client").path("isml").request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class);

		System.out.println("LS : If a client is money laundry? -> " + res25);
	}

}
