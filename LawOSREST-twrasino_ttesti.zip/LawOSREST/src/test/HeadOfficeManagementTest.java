/**
 * 
 */
package test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author kyria_000
 *
 */
public class HeadOfficeManagementTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void viewNumofClientsPerBranch() {
		Form form = new Form(); 
 		form.param("BranchID", "0"); 
 		String res12 = target.path("rest").path("lawos").path("hom").path("reports").path("branch").path("nclient") 
 				.request().accept(MediaType.APPLICATION_JSON) 
 				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class); 
 
 
 		System.out.println("HOM : numofclients per branch -> " + res12); 

	}
  
  
  @Test
	public void recPerMonthTest() {
		Form form = new Form(); 
 		form.param("BranchID", "0"); 
 		String res13 = target.path("rest").path("lawos").path("hom").path("reports").path("recom").path("permonth") 
 				.request().accept(MediaType.APPLICATION_JSON) 
 				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class); 
 
 		System.out.println("HOM : recommendations per month -> " + res13); 
    
	}
  
  @Test
	public void legalOpPerMonthTest() {
		// legal opinions per month 
 		Form form = new Form(); 
 		form.param("BranchID", "0"); 
 		String res14 = target.path("rest").path("lawos").path("hom").path("reports").path("legalop").path("permonth") 
 				.request().accept(MediaType.APPLICATION_JSON) 
 				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class); 
 
 
 		System.out.println("HOM : legal opinions per month -> " + res14); 
    
	}
  
  
  
  @Test
	public void timesWaitTest() {
		// completed app of a client 
 		Form form = new Form(); 
 		form.param("ID", "1"); 
 		String res15 = target.path("rest").path("lawos").path("hom").path("reports").path("client").path("timeswait") 
 				.request().accept(MediaType.APPLICATION_JSON) 
 				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class); 
 
 		System.out.println("HOM : completed app of a client (timeswait) -> " + res15); 
       
	}
  
  
  @Test
	public void weeklyAttTest() {
		// Weekly reports for attended number of clients per branch per weekday 
 		Form form = new Form(); 
 		form.param("BranchID", "0"); 
 		String res16 = target.path("rest").path("lawos").path("hom").path("reports").path("weekly").path("perbranch") 
 				.path("attended").request().accept(MediaType.APPLICATION_JSON) 
 				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class); 
 
 
 		System.out.println("HOM : Weekly reports for attended number of clients per branch per weekday -> " + res16); 

	}
  
  @Test
	public void weeklyVisTest() {
		// Weekly reports for total visits of clients per branch per weekday 
 		Form form = new Form(); 
 		form.param("BranchID", "0"); 
 		String res17 = target.path("rest").path("lawos").path("hom").path("reports").path("weekly").path("perbranch") 
 				.path("all").request().accept(MediaType.APPLICATION_JSON) 
 				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class); 
 
 
 		System.out.println("HOM : Weekly reports for total visits of clients per branch per weekday -> " + res17); 

	}
  
  @Test
	public void weeklyClientTest() {
		// Weekly reports per client 
 		form = new Form(); 
 		form.param("ClientID", "1"); 
 		String res18 = target.path("rest").path("lawos").path("hom").path("reports").path("weekly").path("perclient") 
 				.request().accept(MediaType.APPLICATION_JSON) 
 				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class); 
 
  		System.out.println("HOM : Weekly reports per client -> " + res18); 

	}
  
  

}
