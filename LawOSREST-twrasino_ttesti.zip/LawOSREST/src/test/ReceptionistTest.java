/**
 * 
 */
package test;

import static org.junit.Assert.*;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

/**
 * @author hmicha01
 *
 */
public class ReceptionistTest {

	ClientConfig config = new ClientConfig();
	Client client = ClientBuilder.newClient(config);
	WebTarget target = client.target(UriBuilder.fromUri("http://localhost:80/LawOSREST").build());

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {

	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Ignore
	@Test
	public void newappTest() {
		// Create a new request object
		Form form = new Form();
		form.param("date", "2016-10-10");
		form.param("time", "11:00:00");
		form.param("clientID", "1");
		form.param("legalStaffID", "1");
		form.param("caseID", "1");
		String res2 = target.path("rest").path("lawos").path("receptionist").path("newapp").request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class);

		if (res2.equals("1"))
			System.out.println("Correct response from server: " + res2 + " Inserted Successfully" + "\n\n");
		else
			System.out.println("Not inserted, code: " + res2 + "\n\n");
	}

	@Ignore
	@Test
	public void delappTest() {
		// Create a new request object
		Form form = new Form();
		form.param("appointmentID", "31");
		String res3 = target.path("rest").path("lawos").path("receptionist").path("delapp").request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class);

		if (res3.equals("1"))
			System.out.println("Correct response from server: " + res3 + " Deleted Successfully" + "\n\n");
		else
			System.out.println("Not deleted, code: " + res3 + "\n\n");
	}

	@Test
	public void incTest() {
		// View all incomplete appointments
		String res4 = target.path("rest").path("lawos").path("receptionist").path("app").path("inc").request()
				.accept(MediaType.APPLICATION_JSON).get(String.class);

		System.out.println("The rest Service responds with the following jSon: \n" + res4 + "\n\n");
	}

	@Test
	public void comTest() {
		// View all completed appointments
		String res5 = target.path("rest").path("lawos").path("receptionist").path("app").path("com").request()
				.accept(MediaType.APPLICATION_JSON).get(String.class);

		System.out.println("The rest Service responds with the following jSon: \n" + res5 + "\n\n");
	}

	@Test
	public void passedTest() {
		// View all passed appointments
		String res6 = target.path("rest").path("lawos").path("receptionist").path("app").path("passed").request()
				.accept(MediaType.APPLICATION_JSON).get(String.class);
		System.out.println("The rest Service responds with the following jSon: \n" + res6 + "\n\n");
	}

	@Test
	public void markTest() {
		// Mark current appointment
		Form form = new Form();
		form.param("appointmentID", "13");
		String res7 = target.path("rest").path("lawos").path("receptionist").path("app").path("mark").request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class);
		System.out.println("The rest Service responds with the following jSon: \n" + res7 + "\n\n");
	}

	@Test
	public void searchClientTest() {
		// View current client record
		Form form = new Form();
		form.param("ID", "1");
		String res8 = target.path("rest").path("lawos").path("search").path("client").request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class);
		System.out.println("The rest Service responds with the following jSon: \n" + res8 + "\n\n");
	}

	@Test
	public void recomStrategiesTest() {
		// Get Recommendation strategies
		Form form = new Form();
		form.param("ID", "1");
		String res9 = target.path("rest").path("lawos").path("recom").path("strategies").request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class);
		System.out.println("The rest Service responds with the following jSon: \n" + res9 + "\n\n");
	}

}
