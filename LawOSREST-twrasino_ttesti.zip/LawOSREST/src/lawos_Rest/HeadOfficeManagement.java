package lawos_Rest;

import javax.ws.rs.Path;

@Path("/lawos/lrs")
public class HeadOfficeManagement {
	
	
	
}// end of class
