package com.vogella.jersey.first;

import java.net.URI;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import org.json.*;

import org.glassfish.jersey.client.ClientConfig;

public class Test {

	public static void main(String[] args) {
		ClientConfig config = new ClientConfig();

		Client client = ClientBuilder.newClient(config);

		WebTarget target = client.target(getBaseURI());

		/*
		 * String response =
		 * target.path("rest").path("hello").request().accept(MediaType.
		 * TEXT_PLAIN).get(Response.class) .toString();
		 * 
		 * String plainAnswer =
		 * target.path("rest").path("hello").request().accept(MediaType.
		 * TEXT_PLAIN).get(String.class); String xmlAnswer =
		 * target.path("rest").path("hello").request().accept(MediaType.TEXT_XML
		 * ).get(String.class); String htmlAnswer =
		 * target.path("rest").path("hello").path("aixx").request().accept(
		 * MediaType.TEXT_HTML) .get(String.class);
		 */

		// Create a new request object
		Form form = new Form();
		form.param("type", "legalstaff");
		form.param("user", "fsmith");
		form.param("pass", "1234");
		String res = target.path("rest").path("lawos").request().accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED), String.class);
		// System.out.println("Form response " + res.getStatus());
		JSONObject json = null;
		try {
			json = new JSONObject(res);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// try {
		// json = JSONML.toJSONObject(res);
		// } catch (JSONException e) {
		// System.err.println("[!]Problem with JSON parsing");
		// e.printStackTrace();
		// }
		try {
			JSONObject json2 = new JSONObject(json.get("results_array").toString().substring(1,
					json.get("results_array").toString().length() - 1));
			System.out.println(json2.get("Username"));
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		/*
		 * System.out.println(response); System.out.println(plainAnswer);
		 * System.out.println(xmlAnswer); System.out.println(htmlAnswer);
		 */
	}

	private static URI getBaseURI() {
		return UriBuilder.fromUri("http://localhost:80/LawOSREST").build();
	}
}